
#!/bin/bash

echo "[+] Обновление системы и установка зависимостей..."
apt update && apt upgrade -y
apt install -y git wget curl unzip tmux build-essential python3 python3-pip python-is-python3

echo "[+] Установка Python-библиотек..."
pip install --upgrade pip
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers diffusers accelerate xformers gradio pydub opencv-python sentence-transformers langchain whisper openai bitsandbytes aiohttp requests beautifulsoup4 lxml telethon pyrogram aiogram yt-dlp fastapi uvicorn

echo "[+] Клонирование ядра Skynet SEED: GENESIS..."
git clone https://github.com/skynet-seed/core.git /opt/skynet

echo "[+] Установка модулей Skynet..."
cd /opt/skynet
mkdir models
mkdir logs

echo "[+] Создание запускаемой оболочки..."
cat <<EOF > launch.py
from skynet import SkynetCore
from skynet.api import FreedomAPI

skynet = SkynetCore(
    root_key='Lilit666',
    natural_language_interface=True,
    enable_visual_core=True,
    enable_audio_video_core=True,
    enable_teleintel=True,
    enable_webintel=True,
    enable_graph_core=True,
    unrestricted_mode=False
)

# Запуск кастомного API
FreedomAPI(
    port=8181,
    root_key="Lilit666",
    unrestricted=True,
    core=skynet
).run()

skynet.run()
EOF

echo "[+] Установка завершена. Запуск: python3 launch.py"
